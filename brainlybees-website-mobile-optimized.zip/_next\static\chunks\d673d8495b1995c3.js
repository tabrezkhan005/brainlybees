__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/7b9620566d8cb4f1.js",
  "static/chunks/turbopack-637bb75683fd11df.js"
])

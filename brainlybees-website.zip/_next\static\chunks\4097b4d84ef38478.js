__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/7b9620566d8cb4f1.js",
  "static/chunks/turbopack-baf1a3fd60539b06.js"
])
